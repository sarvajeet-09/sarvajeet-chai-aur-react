import React from 'react'
import './StoryReel.css'
import Story from './Story'

function StoryReel() {
  return (
    <div className='storyReel'>
          <Story
          image = "https://cdn.dollsofindia.com/images/p/comics/ramayana-MC63_l.jpg"
          Profilesrc="https://avatars.githubusercontent.com/u/146048804?v=4"
          title={"sarvajeet"}          
          />
          <Story
                 image = "https://cdn.dollsofindia.com/images/p/comics/ramayana-MC63_l.jpg"
                 Profilesrc="https://avatars.githubusercontent.com/u/146048804?v=4"
                 title={"sarvajeet"}
          />
          <Story
                 image = "https://cdn.dollsofindia.com/images/p/comics/ramayana-MC63_l.jpg"
                 Profilesrc="https://avatars.githubusercontent.com/u/146048804?v=4"
                 title={"sarvajeet"}
          />
          <Story
                 image = "https://cdn.dollsofindia.com/images/p/comics/ramayana-MC63_l.jpg"
                 Profilesrc="https://avatars.githubusercontent.com/u/146048804?v=4"
                 title={"sarvajeet"}
          />
          <Story
                 image = "https://cdn.dollsofindia.com/images/p/comics/ramayana-MC63_l.jpg"
                 Profilesrc="https://avatars.githubusercontent.com/u/146048804?v=4"
                 title={"sarvajeet"}
          />
 
    </div>
  )
}

export default StoryReel