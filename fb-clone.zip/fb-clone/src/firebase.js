// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyAi6gYB3_m7Bsi-Uxj1Pd1VU1aG_JrXe9w",
    authDomain: "fb-clone-7ea47.firebaseapp.com",
    projectId: "fb-clone-7ea47",
    storageBucket: "fb-clone-7ea47.firebasestorage.app",
    messagingSenderId: "514787706953",
    appId: "1:514787706953:web:7d6082237f803d69b6d798",
    measurementId: "G-SXMZ5JK6CH"
  };